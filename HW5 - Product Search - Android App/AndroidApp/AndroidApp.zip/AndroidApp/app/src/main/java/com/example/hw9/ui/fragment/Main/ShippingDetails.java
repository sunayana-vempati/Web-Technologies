package com.example.hw9.ui.fragment.Main;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.hw9.ActivityProductDetails;
import com.example.hw9.R;
import com.example.hw9.utils.WebAPIS;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class ShippingDetails extends Fragment {

    View rootview;
    public static RelativeLayout layout_return_within,layout_return_policy,layout_refund,layout_shipped_by;
    public static TextView store_text,feedback_text,popularity_rating,shipping_text,global_text,handling_text,condition_text,ploicy_text,within_text,refund_text,shipped_text;
    public static ImageView feedback_star;
    public ShippingDetails() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootview = inflater.inflate(R.layout.shipping_information, container, false);

        layout_return_within = (RelativeLayout) rootview.findViewById(R.id.layout_return_within);
        layout_return_policy = (RelativeLayout) rootview.findViewById(R.id.layout_return_policy);
        layout_refund = (RelativeLayout) rootview.findViewById(R.id.layout_refund);
        layout_shipped_by = (RelativeLayout) rootview.findViewById(R.id.layout_shipped_by);



        store_text = (TextView) rootview.findViewById(R.id.store_text);
        feedback_text = (TextView) rootview.findViewById(R.id.feedback_text);
        popularity_rating = (TextView) rootview.findViewById(R.id.popularity_rating);
        shipping_text = (TextView) rootview.findViewById(R.id.shipping_text);
        global_text = (TextView) rootview.findViewById(R.id.global_text);
        handling_text = (TextView) rootview.findViewById(R.id.handling_text);
        condition_text = (TextView) rootview.findViewById(R.id.condition_text);
        ploicy_text = (TextView) rootview.findViewById(R.id.ploicy_text);
        within_text = (TextView) rootview.findViewById(R.id.within_text);
        refund_text = (TextView) rootview.findViewById(R.id.refund_text);
        shipped_text = (TextView) rootview.findViewById(R.id.shipped_text);
        feedback_star = (ImageView) rootview.findViewById(R.id.feedback_star);
        store_text.setPaintFlags(Paint.UNDERLINE_TEXT_FLAG);
        final WebAPIS webAPIs= new WebAPIS();
        store_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(),"Clicked",Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Intent.ACTION_VIEW);
                WebAPIS webAPIs= new WebAPIS();
                i.setData(Uri.parse("https://www.ebay.com"));
                //if (Uri.parse(webAPIs.getShipNavUrl()) == null)
                //    i.setData(Uri.parse("https://www.ebay.com"));

                //else
                //    i.setData(Uri.parse(webAPIs.getShipNavUrl()));

                getActivity().startActivity(i);
            }
        });
        return rootview;
    }
}