package com.example.hw9;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.hw9.ui.Storage.SharedPreferenceConfig;
import com.example.hw9.ui.fragment.Main.WishlistFragment;
import com.example.hw9.ui.init.ProductDetails;
import com.example.hw9.utils.ImageLoader;
import com.google.gson.Gson;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;

import static android.support.constraint.Constraints.TAG;

public class ProductResultsAdapter extends RecyclerView.Adapter<ProductResultsAdapter.ProductDetailsViewHolder> {
    private List<ProductDetails> productDetailList;
    private Context context;
    private List<ProductDetails> localStorage;
    SharedPreferenceConfig sharedPreferenceConfig;
    ImageLoader imageLoader;

    @RequiresApi(api = Build.VERSION_CODES.N)
    public ProductResultsAdapter(List<ProductDetails> productDetailList, Context context) {
        this.productDetailList = productDetailList;
        this.context = context;
        sharedPreferenceConfig = new SharedPreferenceConfig(ProductResultsAdapter.this.context);
        localStorage = sharedPreferenceConfig.loadSharedPreferencesLogList();
        imageLoader = new ImageLoader(context);
    }

    @NonNull
    @Override
    public ProductDetailsViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_layout, viewGroup, false);
        ProductDetailsViewHolder productDetailsViewHolder = new ProductDetailsViewHolder(view, context, productDetailList, this);
        return productDetailsViewHolder;
    }

    @Override
    public void onBindViewHolder(final ProductDetailsViewHolder viewHolder, final int position) {

        final ProductDetails productDetail = productDetailList.get(position);
        Log.d("HW09","Image in adapter class --- "+productDetail.getProductImage().replace("\"]",""));
        imageLoader.DisplayImage(productDetail.getProductImage().replace("\"]",""),viewHolder.productImage);
        viewHolder.productTitle.setText(productDetail.getProductTitle());
        viewHolder.productZip.setText("Zip: "+productDetail.getProductZip());
        viewHolder.productShipping.setText(productDetail.getProductShipping());
        viewHolder.productCondition.setText(productDetail.getProductCondition());
        viewHolder.productPrice.setText("$"+productDetail.getProductPrice());

        boolean isAlreadyInWish = isInWishList(productDetail.getProductId());
        if (isAlreadyInWish){
            viewHolder.wishIcon.setVisibility(View.GONE);
            viewHolder.wishRemove.setVisibility(View.VISIBLE);
        }

        viewHolder.wishIcon.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View v) {
                sharedPreferenceConfig.saveSharedPreferencesLogList(new Gson().toJson(productDetail));
                viewHolder.wishIcon.setVisibility(View.GONE);
                viewHolder.wishRemove.setVisibility(View.VISIBLE);
                Toast.makeText(context,productDetail.getProductTitle()+"is Added from your cart",Toast.LENGTH_LONG).show();
            }
        });
        viewHolder.wishRemove.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View v) {
                sharedPreferenceConfig.removeFromSharedPref(new Gson().toJson(productDetail));
                viewHolder.wishIcon.setVisibility(View.VISIBLE);
                viewHolder.wishRemove.setVisibility(View.GONE);
                productDetailList.remove(position);
                Toast.makeText(context,productDetail.getProductTitle()+"is Removed from your cart",Toast.LENGTH_LONG).show();
                WishlistFragment.items_count.setText("("+String.valueOf(sharedPreferenceConfig.loadSharedPreferencesLogList().size()+" items):"));
                WishlistFragment.total_price.setText("$"+String.valueOf(Double.parseDouble(WishlistFragment.total_price.getText().toString().replace("$",""))-Double.parseDouble(productDetail.getProductPrice())));
            }
        });
        viewHolder.productImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewHolder.productTitle.getText().toString().trim();
                Intent intent = new Intent(viewHolder.context,ActivityProductDetails.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("prod_title",viewHolder.productTitle.getText().toString().trim());
                intent.putExtra("prod_id",productDetail.getProductId());
                intent.putExtra("prod_price",productDetail.getProductPrice());
                intent.putExtra("prod",new Gson().toJson(productDetail));
                viewHolder.context.startActivity(intent);
            }
        });
        viewHolder.productTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewHolder.productTitle.getText().toString().trim();
                Intent intent = new Intent(viewHolder.context,ActivityProductDetails.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("prod_title",viewHolder.productTitle.getText().toString().trim());
                intent.putExtra("prod_id",productDetail.getProductId());
                intent.putExtra("prod_price",productDetail.getProductPrice());
                intent.putExtra("prod",new Gson().toJson(productDetail));
                viewHolder.context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    private boolean isInWishList(String productId) {
        for (int i = 0; i < localStorage.size(); i++) {
            if (localStorage.get(i).getProductId().equalsIgnoreCase(productId)) {
                Log.i(" In local storage ", "Yes ");
                return true;
            }
        }
        return false;
    }

    public void setUpdateChange(List<ProductDetails> productDetails) {
        productDetailList = productDetails;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return productDetailList.size();
    }

    public static class ProductDetailsViewHolder extends RecyclerView.ViewHolder  {

        public ImageView productImage;
        public TextView productTitle;
        public TextView productZip;
        public TextView productShipping;
        public TextView productCondition;
        public TextView productPrice;
        public ImageView wishIcon,wishRemove;
        public TextView productId;
        public Context context;
        public List<ProductDetails> productDetails;
        public SharedPreferenceConfig sharedPreferenceConfig;
        public ProductResultsAdapter productResultsAdapter;


        public ProductDetailsViewHolder(@NonNull View itemView, Context context, List<ProductDetails> productDetails, ProductResultsAdapter productResultsAdapter) {
            super(itemView);
            this.context = context;
            this.productDetails = productDetails;
            this.productResultsAdapter = productResultsAdapter;

            productImage = itemView.findViewById(R.id.product_image);
            productTitle = itemView.findViewById(R.id.product_title);
            productZip = itemView.findViewById(R.id.product_zip);
            productShipping = itemView.findViewById(R.id.product_shipping);
            productCondition = itemView.findViewById(R.id.product_condition);
            productPrice = itemView.findViewById(R.id.product_price);
            wishIcon = itemView.findViewById(R.id.wish_icon_id);
            wishRemove = itemView.findViewById(R.id.wish_icon_remove);

        }

    }
}
