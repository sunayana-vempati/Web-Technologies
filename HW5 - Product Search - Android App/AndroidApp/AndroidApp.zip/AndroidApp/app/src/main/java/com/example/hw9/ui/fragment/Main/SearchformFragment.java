package com.example.hw9.ui.fragment.Main;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.hw9.Adapter.ZipGetSet;
import com.example.hw9.R;
import com.example.hw9.ui.activity.ProductResults;
import com.example.hw9.ui.init.SearchForm;
import com.example.hw9.utils.WebAPIS;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.regex.Pattern;

public class SearchformFragment extends Fragment {
    public View view;
    public Context context;
    LinearLayout nearbylayout;
    private String keyword;
    private String zipCode;
    ProgressDialog dialog = null;
    int responseCode=0;
    List<ZipGetSet> zipArrayList = new ArrayList<ZipGetSet>();
    List<String> zipList = new ArrayList<String>();
    Boolean zipflag=false,nearby_flag=false;
    Spinner spinner;
    View rootView;
    String responseMessage,postalCode;
    EditText searchkeyword,miles;
    AutoCompleteTextView zipcode;
    CheckBox newca,used,unspecified,localpicup,freeshipping,nearby;
    RadioButton currentlocation,zipenable;
    RadioGroup near_location;
    Button search,clear;
    RadioButton selected;
    String sel = "";

    public SearchformFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_searchform, container, false);
        this.context = view.getContext();

        view.findViewById(R.id.keyword_id).setEnabled(true);
        view.findViewById(R.id.keyword_error_id).setVisibility(View.GONE);

        Spinner spinner = view.findViewById(R.id.category_id);
        List<String> categories = new ArrayList<>();
        categories.add("All");
        categories.add("Art");
        categories.add("Baby");
        categories.add("Books");
        categories.add("Clothing, Shoes & Accessories");
        categories.add("Computers, Tablets & Networking");
        categories.add("Health & Beauty");
        categories.add("Music");
        categories.add("Video Games & Consoles");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(this.context, android.R.layout.simple_spinner_item, categories);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);

        view.findViewById(R.id.new_id).setEnabled(true);
        view.findViewById(R.id.used_id).setEnabled(true);
        view.findViewById(R.id.unspecified_id).setEnabled(true);

        view.findViewById(R.id.local_id).setEnabled(true);
        view.findViewById(R.id.free_id).setEnabled(true);

        view.findViewById(R.id.nearby_checkbox_id).setEnabled(true);
        view.findViewById(R.id.current_loc_radio_id).setEnabled(false);
        view.findViewById(R.id.other_loc_radio_id).setEnabled(false);
        view.findViewById(R.id.other_loc_value_id).setEnabled(false);

        view.findViewById(R.id.search_button_id).setEnabled(true);
        view.findViewById(R.id.clear_button_id).setEnabled(true);

        searchkeyword=(EditText) view.findViewById(R.id.keyword_id);
        zipcode=(AutoCompleteTextView) view.findViewById(R.id.other_loc_value_id);
        miles=(EditText) view.findViewById(R.id.distance_id);
        newca=(CheckBox)view.findViewById(R.id.new_id);
        used=(CheckBox)view.findViewById(R.id.used_id);
        unspecified=(CheckBox)view.findViewById(R.id.unspecified_id);
        localpicup=(CheckBox)view.findViewById(R.id.local_id);
        freeshipping=(CheckBox)view.findViewById(R.id.free_id);
        nearby=(CheckBox)view.findViewById(R.id.nearby_checkbox_id);
        currentlocation=(RadioButton)view.findViewById(R.id.current_loc_radio_id);
        zipenable=(RadioButton)view.findViewById(R.id.other_loc_radio_id);
        near_location=(RadioGroup)view.findViewById(R.id.radio_id);
        search=(Button) view.findViewById(R.id.search_button_id);
        clear=(Button) view.findViewById(R.id.clear_button_id);
        nearbylayout=(LinearLayout) view.findViewById(R.id.nearby_row_id);

        nearby.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    nearby_flag=true;
                    nearbylayout.setVisibility(View.VISIBLE);
                }else{
                    nearby_flag=false;
                    nearbylayout.setVisibility(View.GONE);
                }
            }
        });

        zipcode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                new getZipcode().execute(WebAPIS.ZIP_CODE_LIST+s.toString());
            }
        });

        near_location.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                selected = (RadioButton) view.findViewById(checkedId);
                if (selected.getText().toString().trim().equals("Zip Code")){
                    zipflag=true;
                    zipcode.setVisibility(View.VISIBLE);
                    sel = zipcode.getText().toString().trim();
                }
                else {
                    zipflag=false;
                    zipcode.setVisibility(View.GONE);
                }
            }
        });


        search.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View v) {
                searchProducts(v);
            }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View v) {
                clearAllFields(v);
            }
        });


        view.findViewById(R.id.keyword_id).setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                view.findViewById(R.id.keyword_error_id).setVisibility(View.GONE);
                return false;
            }
        });

        view.findViewById(R.id.other_loc_value_id).setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                view.findViewById(R.id.other_loc_error_id).setVisibility(View.GONE);
                return false;
            }
        });

        view.findViewById(R.id.nearby_checkbox_id).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                view.findViewById(R.id.current_loc_radio_id).setEnabled(true);
                view.findViewById(R.id.other_loc_radio_id).setEnabled(true);
                view.findViewById(R.id.other_loc_value_id).setEnabled(false);

            }

        });
        view.findViewById(R.id.current_loc_radio_id).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RadioButton r= ((RadioButton) view.findViewById(R.id.other_loc_radio_id));
                clearRadio(r);
                view.findViewById(R.id.other_loc_value_id).setEnabled(false);
                view.findViewById(R.id.other_loc_error_id).setVisibility(View.GONE);
            }

        });

        view.findViewById(R.id.other_loc_radio_id).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                view.findViewById(R.id.other_loc_value_id).setEnabled(true);
                RadioButton r= ((RadioButton) view.findViewById(R.id.current_loc_radio_id));
                clearRadio(r);
            }
        });
        return view;
    }


    @SuppressLint("ResourceType")
    public void clearAllFields(View view1) {
        ((TextView) view.findViewById(R.id.keyword_id)).setText("");
        view.findViewById(R.id.keyword_error_id).setVisibility(View.GONE);
        ((Spinner) view.findViewById(R.id.category_id)).setSelection(0);

        CheckBox temp =  ((CheckBox) view.findViewById(R.id.new_id));
        CheckBox temp1 =  ((CheckBox) view.findViewById(R.id.used_id));
        CheckBox temp2 =  ((CheckBox) view.findViewById(R.id.unspecified_id));
        CheckBox temp3 =  ((CheckBox) view.findViewById(R.id.local_id));
        CheckBox temp4 =  ((CheckBox) view.findViewById(R.id.free_id));
        CheckBox temp5 =  ((CheckBox) view.findViewById(R.id.nearby_checkbox_id));
        clearCheck(temp); clearCheck(temp1); clearCheck(temp2); clearCheck(temp3); clearCheck(temp4);clearCheck(temp5);

        ((TextView) view.findViewById(R.id.distance_id)).setText("10");
        view.findViewById(R.id.distance_id).setEnabled(false);
        ((RadioGroup) view.findViewById(R.id.radio_id)).check(R.id.current_loc_radio_id);
        view.findViewById(R.id.current_loc_radio_id).setEnabled(false);
        RadioButton r= ((RadioButton) view.findViewById(R.id.other_loc_radio_id));
        clearRadio(r);
        ((TextView) view.findViewById(R.id.other_loc_value_id)).setText("");
        view.findViewById(R.id.other_loc_radio_id).setEnabled(false);
        view.findViewById(R.id.other_loc_value_id).setEnabled(false);
        view.findViewById(R.id.other_loc_error_id).setVisibility(View.GONE);
    }



    @RequiresApi(api = Build.VERSION_CODES.N)
    public void searchProducts(View view1){

        Pattern p = Pattern.compile("[^a-zA-Z0-9' ]");
        boolean valid = false;
        String keyword = searchkeyword.getText().toString();
        if (keyword == null || keyword.length() <= 0 || p.matcher(keyword).find()) {
            view.findViewById(R.id.keyword_error_id).setVisibility(View.VISIBLE);
            valid = true;
        }

        boolean otherLoc = false;
        if (zipflag) {
            String zip = zipcode.getText().toString();
            if (zip == null || zip.length() <= 0) {
                view.findViewById(R.id.other_loc_error_id).setVisibility(View.VISIBLE);
                valid = true;

            }
            otherLoc=true;

        }
        if (valid) {
            Toast.makeText(view.getContext(), "Fill in the required fields",
                    Toast.LENGTH_LONG).show();
            return;
        }

        Spinner spinner = view.findViewById(R.id.category_id);
        String category = spinner.getSelectedItem().toString();
        int distance = 10;

        Editable textView = ((EditText) view.findViewById(R.id.distance_id)).getText();
        if (!textView.toString().equalsIgnoreCase("") && Objects.nonNull(textView)) {
            distance = Integer.valueOf(textView.toString());
        }

        RadioGroup radioGroup;
        SearchForm searchform = new SearchForm();
        searchform.setKeyword(keyword);
        searchform.setCategory(category);
        searchform.setDistance(distance);

        CheckBox temp =  ((CheckBox) view.findViewById(R.id.new_id));
        CheckBox temp1 =  ((CheckBox) view.findViewById(R.id.used_id));
        CheckBox temp2 =  ((CheckBox) view.findViewById(R.id.unspecified_id));
        CheckBox temp3 =  ((CheckBox) view.findViewById(R.id.local_id));
        CheckBox temp4 =  ((CheckBox) view.findViewById(R.id.free_id));
        CheckBox temp5 =  ((CheckBox) view.findViewById(R.id.nearby_checkbox_id));

        if (temp.isChecked())
            searchform.setNew("true");
        else
            searchform.setNew("false");

        if (temp1.isChecked())
            searchform.setUsed("true");
        else
            searchform.setUsed("false");

        if (temp2.isChecked())
            searchform.setUnspecified("true");
        else
            searchform.setUnspecified("false");

        if (temp3.isChecked())
            searchform.setLocal("true");
        else
            searchform.setLocal("false");

        if (temp4.isChecked())
            searchform.setFree("true");
        else
            searchform.setFree("false");

        radioGroup = view.findViewById(R.id.radio_id);

        int selectedId = radioGroup.getCheckedRadioButtonId();

        if (((RadioButton) view.findViewById(selectedId)).getText().toString().contains("Current")) {
            zipcode.setText("");
        }
        else{
            searchform.setOtherLocation(true);
        }

        if (otherLoc) {
            searchform.setLocation(((EditText) view.findViewById(R.id.other_loc_value_id)).getText().toString());
        }

        Intent newIntent = new Intent(this.context, ProductResults.class);
        ProductResults.initList();
        newIntent.putExtra("keyword",searchkeyword.getText().toString().trim());
        newIntent.putExtra("zip",zipcode.getText().toString());
        newIntent.putExtra("searchForm", new Gson().toJson(searchform));
        startActivity(newIntent);

    }

    public void clearCheck(CheckBox ch)
    {
        if (ch.isChecked())
            ch.toggle();
    }
    public void clearRadio(RadioButton r)
    {
        if (r.isChecked())
            r.toggle();
    }

    public class getZipcode extends AsyncTask<String, String, String> {

        protected void onPreExecute() {
            super.onPreExecute();

        }
        @Override
        protected String doInBackground(String... voids) {

            StringBuffer stringBuffer = new StringBuffer();
            try {
                URL url = new URL(voids[0]);
                HttpURLConnection httpConnection = (HttpURLConnection) url.openConnection();
                httpConnection.connect();
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK)
                {
                    InputStream stream = httpConnection.getInputStream();
                    InputStreamReader isr = new InputStreamReader(stream);
                    BufferedReader br = new BufferedReader(isr);
                    String line = "";
                    while ((line = br.readLine()) != null) {
                        stringBuffer.append(line + "\n");
                    }
                    responseCode = httpConnection.getResponseCode();
                    return stringBuffer.toString();

                } else {
                    return "Not valid";
                }
            }
            catch (Exception e) {
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            if(responseCode==200){

            }
            else {
                Toast.makeText(context.getApplicationContext(), "Server down,Please Try Again After some time", Toast.LENGTH_LONG).show();
            }
            zipList.clear();
            try {

                JSONObject jsonObject = new JSONObject(result);
                Log.d("CFMS","Result Incidents of User VOltE ------ "+result);

                JSONArray Get_array_Obj = jsonObject.getJSONArray("postalCodes");
                Log.d("CFMS", "result = " +Get_array_Obj.length());

                if (!jsonObject.isNull("postalCodes")){

                    for (int j = 0; j < Get_array_Obj.length(); j++) {

                        JSONObject ReasonListObj = Get_array_Obj.getJSONObject(j);

                        String adminCode2 = ReasonListObj.getString("adminCode2");
                        String adminCode1 = ReasonListObj.getString("adminCode1");
                        String adminName2 = ReasonListObj.getString("adminName2");
                        String lng = ReasonListObj.getString("lng");
                        String countryCode = ReasonListObj.getString("countryCode");

                        postalCode = ReasonListObj.getString("postalCode");
                        String adminName1 = ReasonListObj.getString("adminName1");
                        String ISO3166 = ReasonListObj.getString("ISO3166-2");
                        String placeName = ReasonListObj.getString("placeName");
                        String lat = ReasonListObj.getString("lat");

                        zipList.add(postalCode);

                        ZipGetSet obj = new ZipGetSet();
                        obj.setAdminCode2(adminCode2);
                        obj.setAdminCode1(adminCode1);
                        obj.setAdminName2(adminName2);
                        obj.setLng(lng);
                        obj.setCountryCode(countryCode);
                        obj.setAdminName1(adminName1);
                        obj.setISO3166(ISO3166);
                        obj.setPlaceName(placeName);
                        obj.setLat(lat);
                        obj.setPostalCode(postalCode);
                        zipArrayList.add(obj);

                        //Log.d("CFMS","incidentList  === "+ incidentList);

                        ArrayAdapter<String> getAdapterList = new ArrayAdapter<String>(context.getApplicationContext(), R.layout.spinner_style, zipList);

                        zipcode.setAdapter(getAdapterList);
                        //incidents.setText("INC");
                        zipcode.setThreshold(1);

                        zipcode.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                                String selected = (String) adapterView.getItemAtPosition(i);

                                for(int j=0;j<zipArrayList.size();j++){
                                    if(selected.equals(zipArrayList.get(j).getPostalCode())){


                                        postalCode = zipArrayList.get(j).getPostalCode();

                                        Log.d("CFMS"," incidentList.get(position); = "+ postalCode);

                                        break;
                                    }
                                }
                            }
                        });
                    }
                }
                else {
                    Toast.makeText(context.getApplicationContext(),responseMessage,Toast.LENGTH_LONG).show();
                }

            }
            catch (Exception e) {

            }

        }
    }

}