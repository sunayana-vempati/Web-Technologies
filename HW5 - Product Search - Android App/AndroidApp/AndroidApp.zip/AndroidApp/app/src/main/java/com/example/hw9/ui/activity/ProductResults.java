package com.example.hw9.ui.activity;

import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.hw9.ProductResultsAdapter;
import com.example.hw9.R;
import com.example.hw9.ui.fragment.Main.SearchformFragment;
import com.example.hw9.ui.init.ProductDetails;
import com.example.hw9.ui.init.SearchForm;
import com.example.hw9.utils.GPSTracker;
import com.example.hw9.utils.WebAPIS;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProductResults extends AppCompatActivity {

    public static RecyclerView recyclerView;
    public static RecyclerView.LayoutManager layoutManager;
    public static ProductResultsAdapter adaptor;
    public static List<ProductDetails> productDetails = new ArrayList<>();
    public static Context applicationCtx;
    public static String keywordFromBack = "";

    public static TextView count,keyword;
    public static LinearLayout results_showing;

    public SearchForm searchform;
    public AlphaAnimation inAnimation;
    static AlphaAnimation outAnimation;

    static FrameLayout progressBarHolder;
    public static GPSTracker gpsTracker;
    public static String zip = "";
    static View noRecordView;

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    public static void initList() {
        productDetails = new ArrayList<>();
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onResume() {
        super.onResume();
        ProductResults.adaptor = new ProductResultsAdapter(productDetails, ProductResults.applicationCtx);
        ProductResults.recyclerView.setAdapter(ProductResults.adaptor);
        return;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.results_product);

        count = (TextView) findViewById(R.id.count);
        keyword = (TextView) findViewById(R.id.keyword);
        results_showing = (LinearLayout) findViewById(R.id.results_showing);

        keywordFromBack = getIntent().getStringExtra("keyword");

        gpsTracker = new GPSTracker(getApplicationContext());

        zip = getIntent().getStringExtra("zip");

        try {
            Toolbar toolbar = findViewById(R.id.toolbar);
            toolbar.setTitle("Search Results");
            setSupportActionBar(toolbar);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        catch(Exception e){}
        searchform = new Gson().fromJson(getIntent().getStringExtra("searchForm"), SearchForm.class);
        recyclerView = findViewById(R.id.recyclerview);
        noRecordView = findViewById(R.id.no_record_found);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        applicationCtx = getApplicationContext();

        //    if (Objects.isNull(searchform)) {
        //   return;
        //     }

        progressBarHolder = findViewById(R.id.progressBarHolder2);
        progressBarHolder.dispatchDisplayHint(View.VISIBLE);
        progressBarHolder.setAnimation(inAnimation);
        progressBarHolder.setVisibility(View.VISIBLE);
        if (searchform.isOtherLocation()) {
            FindOtherLocationZip findOtherLocationZip = new FindOtherLocationZip();
            findOtherLocationZip.execute(new Gson().toJson(searchform));
        } else {
            FindCurrentLocationZip findCurrentLocationZip = new FindCurrentLocationZip();
            findCurrentLocationZip.execute(new Gson().toJson(searchform));

        }

    }
}

class FindProductResults extends AsyncTask<String, Integer, String> {

    public Map<String, String> categoryValue = new HashMap<>();

    public List<ProductDetails> findProductResults() {
        return productDetails;
    }

    public List<ProductDetails> productDetails = new ArrayList<>();


    @Override
    protected String doInBackground(String... strings) {

        categoryValue.put("All", "all");
        categoryValue.put("Art", "550");
        categoryValue.put("Baby", "2984");
        categoryValue.put("Books", "267");
        categoryValue.put("Clothing, Shoes & Accessories", "11450");
        categoryValue.put("Computers, Tablets & Networking", "58058");
        categoryValue.put("Health & Beauty", "26395");
        categoryValue.put("Music", "11233");
        categoryValue.put("Video Games & Consoles", "1249");

        StringBuffer surl = new StringBuffer();
        SearchForm searchForm = new Gson().fromJson(strings[0], SearchForm.class);
        surl.append(WebAPIS.FIND_RES_LIST);
        surl.append(searchForm.keyword).append("&category=");
        //"+ ProductResults.gpsTracker.getPostalCode(ProductResults.applicationCtx) +"

        surl.append(categoryValue.get(searchForm.category)).append("&loc="+ ((ProductResults.zip.equals("") || ProductResults.zip.isEmpty())? ProductResults.gpsTracker.getPostalCode(ProductResults.applicationCtx) : ProductResults.zip));
        surl.append("&distance=");
        surl.append(searchForm.distance).append("&free=");
        surl.append(searchForm.free).append("&local=");
        surl.append(searchForm.local).append("&new1=");
        surl.append(searchForm.new1).append("&used=");
        surl.append(searchForm.used).append("&unspecified=");
        surl.append(searchForm.unspecified);


        Log.i("Hitting Url ... ", surl.toString().replaceAll(" ","%20"));

        StringBuilder stringBuilder = new StringBuilder();
        HttpURLConnection connection = null;
        URL temp_url;
        try {

            temp_url = new URL(surl.toString().replaceAll(" ","%20"));
            connection = (HttpURLConnection) temp_url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(20000);
            connection.setReadTimeout(20000);

            connection.connect();

            BufferedReader rd = new BufferedReader(new InputStreamReader(connection.getInputStream()));


            String line;
            while ((line = rd.readLine()) != null) {
                stringBuilder.append(line);
            }

            rd.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
        return stringBuilder.toString();
    }


    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onPostExecute(String response) {

        if (response.isEmpty()){
            ProductResults.progressBarHolder.setVisibility(View.VISIBLE);
        }
        else {
            productDetails = processResponse(response);
            ProductResults.productDetails = productDetails;
            ProductResults.adaptor = new ProductResultsAdapter(productDetails, ProductResults.applicationCtx);
            ProductResults.recyclerView.setLayoutManager(new GridLayoutManager(ProductResults.applicationCtx, 2));
            ProductResults.recyclerView.setAdapter(ProductResults.adaptor);
            ProductResults.progressBarHolder.setAnimation(ProductResults.outAnimation);
            ProductResults.progressBarHolder.setVisibility(View.GONE);
        }
    }

    private List<ProductDetails> processResponse(String response) {
        try {
            Log.i("Hitting Url  inside..",response);
            JSONObject jsonObject = new JSONObject(response);
            String resultscount = jsonObject.getJSONArray("findItemsAdvancedResponse").getJSONObject(0).getJSONArray("searchResult").getJSONObject(0).getString("@count");
            Log.i("Hitting Url Param..",resultscount);
            if (resultscount.equals("0")){
                ProductResults.noRecordView.setVisibility(View.VISIBLE);
                ProductResults.results_showing.setVisibility(View.GONE);
            }else {
                ProductResults.results_showing.setVisibility(View.VISIBLE);
                ProductResults.count.setText(resultscount);
                ProductResults.keyword.setText(ProductResults.keywordFromBack);
                ProductResults.noRecordView.setVisibility(View.GONE);
                JSONArray resultsTable = jsonObject.getJSONArray("findItemsAdvancedResponse").getJSONObject(0).getJSONArray("searchResult").getJSONObject(0).getJSONArray("item");
                Log.i("Hitting Url Param..",String.valueOf(resultsTable));
                for (int i = 0; i < resultsTable.length(); i++) {
                    ProductDetails resultsTableContent = new ProductDetails();


                    Log.i("HW09","before");
                    if (!resultsTable.getJSONObject(i).isNull("galleryURL")) {
                        Log.i("HW09","after");
                        resultsTableContent.setProductImage(resultsTable.getJSONObject(i).getString("galleryURL").replace("\\/", "/").replace("[\"", "").replace("]\"", ""));

                    }else
                    {

                        resultsTableContent.setProductImage("https://upload.wikimedia.org/wikipedia/commons/thumb/5/5a/Info_Simple_bw.svg/1024px-Info_Simple_bw.svg.png");
                    }



                    if (!resultsTable.getJSONObject(i).isNull("title")) {
                        resultsTableContent.setProductTitle(resultsTable.getJSONObject(i).getString("title").replace("[\"", "").replace("\"]", ""));

                    }else {
                        resultsTableContent.setProductTitle("N/A");
                    }

                    if (!resultsTable.getJSONObject(i).isNull("postalCode")) {
                        resultsTableContent.setProductZip(resultsTable.getJSONObject(i).getString("postalCode").replace("[\"", "").replace("\"]", ""));

                    }else {
                        resultsTableContent.setProductZip("N/A");
                    }

                    if (!resultsTable.getJSONObject(i).getJSONArray("sellingStatus").getJSONObject(0).getJSONArray("currentPrice").getJSONObject(0).isNull("__value__")) {
                        resultsTableContent.setProductPrice(resultsTable.getJSONObject(i).getJSONArray("sellingStatus").getJSONObject(0).getJSONArray("currentPrice").getJSONObject(0).getString("__value__").replace("[\"", "").replace("\"]", ""));

                    }else {
                        resultsTableContent.setProductPrice("N/A");
                    }


                    if (!resultsTable.getJSONObject(i).getJSONArray("condition").getJSONObject(0).isNull("conditionDisplayName")) {
                        resultsTableContent.setProductCondition(resultsTable.getJSONObject(i).getJSONArray("condition").getJSONObject(0).getString("conditionDisplayName").replace("[\"", "").replace("\"]", ""));

                    }else {
                        resultsTableContent.setProductCondition("N/A");
                    }

                    if (!resultsTable.getJSONObject(i).getJSONArray("shippingInfo").getJSONObject(0).getJSONArray("shippingServiceCost").getJSONObject(0).isNull("__value__")) {
                        resultsTableContent.setProductShipping(resultsTable.getJSONObject(i).getJSONArray("shippingInfo").getJSONObject(0).getJSONArray("shippingServiceCost").getJSONObject(0).getString("__value__").replace("[\"", "").replace("\"]", ""));

                    }else {
                        resultsTableContent.setProductShipping("N/A");
                    }

                    if (!resultsTable.getJSONObject(i).isNull("itemId")) {
                        resultsTableContent.setProductId(resultsTable.getJSONObject(i).getString("itemId").replace("[\"", "").replace("\"]", ""));

                    }else {
                        resultsTableContent.setProductId("N/A");
                    }

                    if (!resultsTable.getJSONObject(i).isNull("viewItemURL")) {
                        resultsTableContent.setProductUrl(resultsTable.getJSONObject(i).getString("viewItemURL").replace("[\"", "").replace("\"]", ""));

                    }else {
                        resultsTableContent.setProductUrl("N/A");
                    }



                    //resultsTableContent.setProductImage(resultsTable.getJSONObject(i).getString("galleryURL").replace("\\/", "/").replace("[\"", "").replace("]\"", ""));
                    //resultsTableContent.setProductTitle(resultsTable.getJSONObject(i).getString("title").replace("[\"", "").replace("\"]", ""));
                    //resultsTableContent.setProductZip(resultsTable.getJSONObject(i).getString("postalCode").replace("[\"", "").replace("\"]", ""));
                    //resultsTableContent.setProductPrice(resultsTable.getJSONObject(i).getJSONArray("sellingStatus").getJSONObject(0).getJSONArray("currentPrice").getJSONObject(0).getString("__value__").replace("[\"", "").replace("\"]", ""));
                    //resultsTableContent.setProductCondition(resultsTable.getJSONObject(i).getJSONArray("condition").getJSONObject(0).getString("conditionDisplayName").replace("[\"", "").replace("\"]", ""));
                    //resultsTableContent.setProductShipping(resultsTable.getJSONObject(i).getJSONArray("shippingInfo").getJSONObject(0).getJSONArray("shippingServiceCost").getJSONObject(0).getString("__value__").replace("[\"", "").replace("\"]", ""));
                    //resultsTableContent.setProductId(resultsTable.getJSONObject(i).getString("itemId").replace("[\"", "").replace("\"]", ""));
                    //resultsTableContent.setProductUrl(resultsTable.getJSONObject(i).getString("viewItemURL").replace("[\"", "").replace("\"]", ""));
                    productDetails.add(resultsTableContent);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
            // ProductResults.noRecordView.setVisibility(View.VISIBLE);
        }

        return productDetails;
    }
}


class FindCurrentLocationZip extends AsyncTask<String, Integer, SearchForm> {


    public SearchForm getSearchForm() {
        return searchForm;
    }

    private SearchForm searchForm;


    public List<ProductDetails> findProductResults() {
        return productDetails;
    }

    public List<ProductDetails> productDetails = new ArrayList<>();
    @Override
    protected SearchForm doInBackground(String... strings) {

        searchForm = new Gson().fromJson(strings[0], SearchForm.class);

        return searchForm;
    }

    @Override
    protected void onPostExecute(SearchForm searchform) {
        FindProductResults findProductResults = new FindProductResults();
        findProductResults.execute(new Gson().toJson(searchform));
        productDetails = findProductResults.findProductResults();
    }

}

class FindOtherLocationZip extends AsyncTask<String, Integer, SearchForm> {

    public SearchForm getSearchForm() {
        return searchForm;
    }

    private SearchForm searchForm;

    public String getGeoHashCode() {
        return geoHashCode;
    }

    private String geoHashCode;

    @Override
    protected SearchForm doInBackground(String... strings) {

        searchForm = new Gson().fromJson(strings[0], SearchForm.class);

        return searchForm;
    }

    @Override
    protected void onPostExecute(SearchForm searchform) {
        FindCurrentLocationZip findCurrentLocationZip = new FindCurrentLocationZip();
        findCurrentLocationZip.execute(new Gson().toJson(searchform));

    }
}



