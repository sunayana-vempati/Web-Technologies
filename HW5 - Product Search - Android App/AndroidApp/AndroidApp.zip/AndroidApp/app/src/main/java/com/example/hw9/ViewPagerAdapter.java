package com.example.hw9;

import android.content.Context;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;


import com.example.hw9.ui.fragment.Main.SearchformFragment;

import com.example.hw9.ui.fragment.Main.WishlistFragment;


public class ViewPagerAdapter extends FragmentPagerAdapter {

    private Context myContext;
    int totalTabs;

    public ViewPagerAdapter(Context context, FragmentManager fm, int totalTabs) {
        super(fm);
        myContext = context;
        this.totalTabs = totalTabs;
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                SearchformFragment searchformFragment = new SearchformFragment();
                return searchformFragment;
            case 1:
                WishlistFragment wishlistFragment = new WishlistFragment();
                return wishlistFragment;
            default:
                return null;
        }
    }
    @Override
    public int getCount() {
        return totalTabs;
    }
}