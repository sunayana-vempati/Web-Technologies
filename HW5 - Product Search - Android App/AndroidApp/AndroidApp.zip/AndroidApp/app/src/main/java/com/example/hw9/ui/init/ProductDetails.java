package com.example.hw9.ui.init;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@NoArgsConstructor
public class ProductDetails {
    public String productTitle;

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

    public void setProductTitle(String productTitle) {
        this.productTitle = productTitle.toUpperCase();
    }

    public void setProductZip(String productZip) {
        this.productZip = productZip;
    }

    public void setProductPrice(String productPrice) {
        this.productPrice = productPrice;
    }

    public void setProductShipping(String productShipping) {
        if(Double.parseDouble(productShipping)==0.0)
            this.productShipping = "Free Shipping";
        else
            this.productShipping= "$"+ productShipping;
    }
    public void setProductCondition(String productCondition) {
        this.productCondition = productCondition;
    }
    public void setProductId(String productId) {   this.productId = productId;   }

    public void setProductUrl(String url) {   this.productUrl = productUrl;   }

    public void setWish(boolean wish) {
        isInWish = wish;
    }

    private String productImage;
    private String productZip;
    private String productPrice;
    private String productShipping;
    private String productCondition;
    private String productId;
    public String productUrl;

    public String getViewItemURL() {
        return viewItemURL;
    }

    public void setViewItemURL(String viewItemURL) {
        this.viewItemURL = viewItemURL;
    }

    public String viewItemURL;
    private boolean isInWish;

    public String shippingPrice;
    public String shippingCost;

    public String getItemURL() {
        return itemURL;
    }

    public void setItemURL(String itemURL) {
        this.itemURL = itemURL;
    }

    public String itemURL;

    public boolean isInWish() {
        return isInWish;
    }

    public void setInWish(boolean inWish) {
        isInWish = inWish;
    }

    public String getShippingPrice() {
        return shippingPrice;
    }

    public void setShippingPrice(String shippingPrice) {
        this.shippingPrice = shippingPrice;
    }

    public String getShippingCost() {
        return shippingCost;
    }

    public void setShippingCost(String shippingCost) {
        if(Double.parseDouble(shippingCost)==0.0)
            this.shippingCost = "Free Shipping";
        else
            this.shippingCost= "$"+ shippingCost;
    }

    public String getDaysLeft() {
        return daysLeft;
    }

    public void setDaysLeft(String daysLeft) {
        this.daysLeft = daysLeft;
    }

    public String daysLeft;

public String getProductImage(){return productImage;}
    public String getProductZip(){return productZip;}
    public String getProductTitle(){return productTitle;}
    public String getProductPrice() {
        return productPrice;
    }

    public String getProductShipping() {
        return productShipping;
    }

    public String getProductCondition() {
        return productCondition;
    }

    public String getProductId() {
        return productId;
    }

    public String getProductUrl() {  return productUrl;   }

    public boolean getWish() {
        return isInWish;
    }
}
