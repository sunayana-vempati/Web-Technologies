package com.example.hw9.ui.fragment.Main;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.hw9.ActivityProductDetails;
import com.example.hw9.R;
import com.example.hw9.SimilarResultsAdapter;
import com.example.hw9.ui.init.ProductDetails;
import com.example.hw9.utils.WebAPIS;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class SimilarProducts extends Fragment {
    int responseCode;
    ProgressDialog dialog = null;
    View rootview;
    RecyclerView recyclerview;
    List<ProductDetails> productDetails = new ArrayList<ProductDetails>();
    List<ProductDetails> productDaysSort = new ArrayList<ProductDetails>();
    SimilarResultsAdapter similarResultsAdapter;
    Spinner defaultSpinner,ascSort;
    String spinner1value = "";


    public SimilarProducts() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootview = inflater.inflate(R.layout.similar_information, container, false);
        recyclerview = (RecyclerView) rootview.findViewById(R.id.recyclerview);
        defaultSpinner=(Spinner) rootview.findViewById(R.id.default_sort);
        ascSort=(Spinner) rootview.findViewById(R.id.dasc_sort);
        new getSimilarProducts().execute(WebAPIS.FIND_SIMILAR_PRODUCTS+ActivityProductDetails.productId);
        ascSort.setEnabled(false);
        ascSort.setClickable(false);
        return rootview;
    }
    public static Comparator<ProductDetails> StringDescComparator = new Comparator<ProductDetails>() {

        public int compare(ProductDetails app1, ProductDetails app2) {

            String stringName1 =  String.valueOf(app1);
            String stringName2 =  String.valueOf(app2);

            return stringName2.compareToIgnoreCase(stringName1);
        }
    };


    public static Comparator<ProductDetails> StringAscComparator = new Comparator<ProductDetails>() {

        @Override
        public int compare(ProductDetails o1, ProductDetails o2) {
            String stringName1 = String.valueOf(o1);
            String stringName2 = String.valueOf(o2);

            return stringName1.compareToIgnoreCase(stringName2);
        }

    };
    public static Comparator<ProductDetails> integreAscComparator = new Comparator<ProductDetails>() {

        @Override
        public int compare(ProductDetails o1, ProductDetails o2) {
            Integer stringName1 = (Integer) Integer.parseInt(o1.getDaysLeft());
            Integer stringName2 = (Integer) Integer.parseInt(o2.getDaysLeft());

            return stringName1.compareTo(stringName2);
        }

    };
    public static Comparator<ProductDetails> integreDscComparator = new Comparator<ProductDetails>() {

        @Override
        public int compare(ProductDetails o1, ProductDetails o2) {
            Integer stringName1 = (Integer) Integer.parseInt(o1.getDaysLeft());
            Integer stringName2 = (Integer) Integer.parseInt(o2.getDaysLeft());

            return stringName2.compareTo(stringName1);
        }

    };

    public static Comparator<ProductDetails> doubleDscComparator = new Comparator<ProductDetails>() {

        @Override
        public int compare(ProductDetails o1, ProductDetails o2) {
            Double stringName1 = (Double) Double.parseDouble(o1.getProductPrice());
            Double stringName2 = (Double) Double.parseDouble(o2.getProductPrice());

            return  stringName2.compareTo(stringName1);
        }

    };
    public static Comparator<ProductDetails> doubleAscComparator = new Comparator<ProductDetails>() {

        @Override
        public int compare(ProductDetails o1, ProductDetails o2) {
            Double stringName1 = (Double) Double.parseDouble(o1.getProductPrice());
            Double stringName2 = (Double) Double.parseDouble(o2.getProductPrice());

            return  stringName1.compareTo(stringName2);
        }

    };

    public class getSimilarProducts extends AsyncTask<String, String, String> {

        protected void onPreExecute() {
            super.onPreExecute();
            dialog = new ProgressDialog(getActivity());
            dialog.setMessage("Please wait");
            dialog.setCancelable(false);
            dialog.show();
        }

        @Override
        protected String doInBackground(String... voids) {

            StringBuffer stringBuffer = new StringBuffer();
            try {
                URL url = new URL(voids[0]);
                HttpURLConnection httpConnection = (HttpURLConnection) url.openConnection();
                httpConnection.connect();
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    InputStream stream = httpConnection.getInputStream();
                    InputStreamReader isr = new InputStreamReader(stream);
                    BufferedReader br = new BufferedReader(isr);
                    String line = "";
                    while ((line = br.readLine()) != null) {
                        stringBuffer.append(line + "\n");
                    }
                    responseCode = httpConnection.getResponseCode();
                    return stringBuffer.toString();

                } else {
                    return "Not valid";
                }
            } catch (Exception e) {
            }
            return null;
        }

        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (dialog.isShowing()) {
                dialog.dismiss();
            }

            if (responseCode == 200) {

            } else {
                Toast.makeText(getContext(), "Server down,Please Try Again After some time", Toast.LENGTH_LONG).show();
            }
            try {

               JSONObject jsonObject = new JSONObject(result);
               JSONObject resultsTable = jsonObject.getJSONObject("getSimilarItemsResponse");
               JSONObject itemRecommendations = resultsTable.getJSONObject("itemRecommendations");
             //  Log.d("HW", "resultsTable1==================="+itemRecommendations);
               JSONArray item = itemRecommendations.getJSONArray("item");

               for (int i=0; i< item.length(); i++){
                   ProductDetails getterSetter = new ProductDetails();
                   String itemId = item.getJSONObject(i).getString("itemId");
                   String title = item.getJSONObject(i).getString("title");
                   String viewItemURL = item.getJSONObject(i).getString("viewItemURL");
                   String globalId = item.getJSONObject(i).getString("globalId");
                   String timeLeft = item.getJSONObject(i).getString("timeLeft").split("DT")[0].substring(1);
                   String primaryCategoryId = item.getJSONObject(i).getString("primaryCategoryId");
                   String primaryCategoryName = item.getJSONObject(i).getString("primaryCategoryName");
                   String country = item.getJSONObject(i).getString("country");
                   String imageURL = item.getJSONObject(i).getString("imageURL");
                   String shippingType = item.getJSONObject(i).getString("shippingType");
                   JSONObject buyItNowPriceobj = item.getJSONObject(i).getJSONObject("buyItNowPrice");
                   String buyItNowPrice = buyItNowPriceobj.getString("__value__");
                   JSONObject shippingCostobj = item.getJSONObject(i).getJSONObject("shippingCost");
                   String shippingCost = shippingCostobj.getString("__value__");

                   getterSetter.setProductId(itemId);
                   getterSetter.setProductImage(imageURL);
                   getterSetter.setProductTitle(title);
                   getterSetter.setShippingCost(shippingCost);
                   getterSetter.setProductPrice(buyItNowPrice);
                   getterSetter.setDaysLeft(timeLeft);
                   getterSetter.setItemURL(viewItemURL);


                   productDaysSort.add(getterSetter);
                   productDetails.add(getterSetter);
               }

                ascSort.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        String sortData = ascSort.getSelectedItem().toString();
                        if (sortData.equals("Ascending")){
                            if(spinner1value.equals("Name")){
                            Collections.sort(productDetails, StringAscComparator);
                            }else if(spinner1value.equals("Days")) {
                                Collections.sort(productDetails, integreAscComparator);
                            }else if(spinner1value.equals("Price")) {
                                Collections.sort(productDetails, doubleAscComparator);
                            }
                            similarResultsAdapter.notifyDataSetChanged();
                        }else if (sortData.equals("Descending")){
                            if(spinner1value.equals("Name")){
                                Collections.sort(productDetails, StringDescComparator);
                            }else if(spinner1value.equals("Days")) {
                                Collections.sort(productDetails, integreDscComparator);
                            }else if(spinner1value.equals("Price")) {
                                Collections.sort(productDetails, doubleDscComparator);
                            }
                           // Collections.sort(productDetails, StringDescComparator);
                            similarResultsAdapter.notifyDataSetChanged();
                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {
                        ascSort.setEnabled(false);
                        ascSort.setClickable(false);

                    }
                });

               defaultSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                   @Override
                   public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                       String sel = defaultSpinner.getSelectedItem().toString();
                       if (sel.equals("Default")){
                           spinner1value = "Default";
                           ascSort.setEnabled(false);
                           ascSort.setClickable(false);
                           for (int i=0;i<productDetails.size(); i++){
                               productDetails.set(i,productDaysSort.get(i));
                               ascSort.setEnabled(false);
                               ascSort.setClickable(false);
                           }

                           similarResultsAdapter.notifyDataSetChanged();
                       }else if (sel.equals("Name")){
                           spinner1value = "Name";
                           Collections.sort(productDetails, new Comparator<ProductDetails>() {
                               @Override
                               public int compare(ProductDetails lhs, ProductDetails rhs) {
                                   return lhs.getProductTitle().compareTo(rhs.getProductTitle());
                               }
                           });
                           ascSort.setEnabled(true);
                           ascSort.setClickable(true);
                           similarResultsAdapter.notifyDataSetChanged();
                       }else if (sel.equals("Price")){
                           spinner1value = "Price";
                           Collections.sort(productDetails, new Comparator<ProductDetails>() {
                               @Override
                               public int compare(ProductDetails lhs, ProductDetails rhs) {

                                   return (Double.parseDouble(lhs.getProductPrice()) > Double.parseDouble(rhs.getProductPrice()))? -1 : 1;
                               }
                           });
                           ascSort.setEnabled(true);
                           ascSort.setClickable(true);
                           similarResultsAdapter.notifyDataSetChanged();
                       }
                       else if (sel.equals("Days")){
                           spinner1value = "Days";
                           Collections.sort(productDetails, integreAscComparator);
                           similarResultsAdapter.notifyDataSetChanged();
                           ascSort.setEnabled(true);
                           ascSort.setClickable(true);
                           /*
                           Collections.sort(productDetails, new Comparator<ProductDetails>() {
                               @Override
                               public int compare(ProductDetails lhs, ProductDetails rhs) {
                                   return lhs.getDaysLeft().compareTo(rhs.getDaysLeft());
                               }
                           });

                           similarResultsAdapter.notifyDataSetChanged();*/
                       }
                   }

                   @Override
                   public void onNothingSelected(AdapterView<?> parent) {

                   }
               });
                similarResultsAdapter = new SimilarResultsAdapter(productDetails,getContext());
                recyclerview.setLayoutManager(new LinearLayoutManager(getActivity()));
                recyclerview.setAdapter(similarResultsAdapter);

            } catch (Exception e) {

            }

        }

    }

}