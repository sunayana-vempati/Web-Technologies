package com.example.hw9.ui.fragment.Main;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


import com.example.hw9.ActivityProductDetails;
import com.example.hw9.R;
import com.example.hw9.utils.ImageLoader;
import com.example.hw9.utils.WebAPIS;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


public class ProductInformation extends Fragment {
    int responseCode;
    ProgressDialog dialog = null;
    View rootview;
    LinearLayout layout,specs;
    TextView product_title_info,product_price_info,product_ship_info,desc_text, price_entry, brand_text;
    String prod_price;
    public static String fbproductlink;

    public ProductInformation() {
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        rootview=inflater.inflate(R.layout.product_information, container, false);
        new getProductDetails().execute(WebAPIS.FIND_PRODUCT_DETAILS+ ActivityProductDetails.productId);
        layout = (LinearLayout) rootview.findViewById(R.id.linear);
        specs = (LinearLayout) rootview.findViewById(R.id.lineaer_specs);
        product_title_info = (TextView) rootview.findViewById(R.id.product_title_info);
        product_price_info = (TextView) rootview.findViewById(R.id.product_price_info);
        product_ship_info = (TextView) rootview.findViewById(R.id.product_ship_info);
        desc_text = (TextView) rootview.findViewById(R.id.desc_text);
        price_entry = (TextView) rootview.findViewById(R.id.price_entry);
        brand_text = (TextView) rootview.findViewById(R.id.brand_text);

        prod_price = getActivity().getIntent().getStringExtra("prod_price");



        return rootview;

    }


    public class getProductDetails extends AsyncTask<String, String, String>  {

        protected void onPreExecute() {
            super.onPreExecute();
            dialog = new ProgressDialog(getActivity());
            dialog.setMessage("Please wait");
            dialog.setCancelable(false);
            dialog.show();
        }

        @Override
        protected String doInBackground(String... voids) {

            StringBuffer stringBuffer = new StringBuffer();
            try {
                URL url = new URL(voids[0]);
                Log.d("HW","url == "+voids[0]);
                HttpURLConnection httpConnection = (HttpURLConnection) url.openConnection();
                httpConnection.connect();
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    InputStream stream = httpConnection.getInputStream();
                    InputStreamReader isr = new InputStreamReader(stream);
                    BufferedReader br = new BufferedReader(isr);
                    String line = "";
                    while ((line = br.readLine()) != null) {
                        stringBuffer.append(line + "\n");
                    }
                    responseCode = httpConnection.getResponseCode();
                    return stringBuffer.toString();

                } else {
                    return "Not valid";
                }
            } catch (Exception e) {
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (dialog.isShowing()) {
                dialog.dismiss();
            }

            if (responseCode == 200) {

            } else {
                Toast.makeText(getActivity(), "Server down,Please Try Again After some time", Toast.LENGTH_LONG).show();
            }
            try {

                JSONObject jsonObject = new JSONObject(result);
                JSONObject itemObj = jsonObject.getJSONObject("Item");
                Log.d("HW", "Product Result ------ " + itemObj);

                // product_ship_info.setText(getShippingCost());
                String title ;
                String currentPrice = itemObj.getJSONObject("CurrentPrice").getString("Value");
                String description ;
                // String description = itemObj.getString("Description");
                String viewItemURLForNaturalSearch;

                if (!itemObj.isNull("UserID")) {
                    title = itemObj.getString("UserID");
                }else {
                    title = "";
                }


                if (!itemObj.isNull("Description")) {
                    description = itemObj.getString("Description");
                }else {
                    description = "";
                }

                if (!itemObj.isNull("ViewItemURLForNaturalSearch")) {
                    viewItemURLForNaturalSearch = itemObj.getString("ViewItemURLForNaturalSearch");
                }else {
                    viewItemURLForNaturalSearch = "";
                }


                fbproductlink=viewItemURLForNaturalSearch;
                JSONArray nameValuePair = itemObj.getJSONObject("ItemSpecifics").getJSONArray("NameValueList");
                //Log.d("HW", "viewItemURLForNaturalSearch Result ------ " + viewItemURLForNaturalSearch);
                JSONObject seller = itemObj.getJSONObject("Seller");
                String userID ;
                String feedbackRatingStar ;
                String feedbackScore ;
                String positiveFeedbackPercent;

                if (!seller.isNull("UserID")) {
                    userID = seller.getString("UserID");
                }else {
                    userID = "";
                }

                if (!seller.isNull("FeedbackRatingStar")) {
                    feedbackRatingStar = seller.getString("FeedbackRatingStar");
                }else {
                    feedbackRatingStar = "";
                }

                if (!seller.isNull("FeedbackScore")) {
                    feedbackScore = seller.getString("FeedbackScore");
                }else {
                    feedbackScore = "";
                }

                if (!seller.isNull("PositiveFeedbackPercent")) {
                    positiveFeedbackPercent = seller.getString("PositiveFeedbackPercent");
                }else {
                    positiveFeedbackPercent = "";
                }



                JSONObject returnPolicy = itemObj.getJSONObject("ReturnPolicy");
                String shippingCostPaidBy;
                String refund;
                String returnsAccepted;
                String returnsWithin;
                //TextView temp ;
                if (!returnPolicy.isNull("Refund")) {
                    refund = returnPolicy.getString("Refund");
                }else {
                    refund = "";
                    ShippingDetails.layout_refund.setVisibility(View.GONE);
                }


                if (!returnPolicy.isNull("ReturnsWithin")) {
                    returnsWithin = returnPolicy.getString("ReturnsWithin");
                }else {
                    returnsWithin = "";

                    ShippingDetails.layout_return_within.setVisibility(View.GONE);


                }


                if (!returnPolicy.isNull("ReturnsAccepted")) {
                    returnsAccepted = returnPolicy.getString("ReturnsAccepted");
                }else {
                    returnsAccepted = "";
                    ShippingDetails.layout_return_policy.setVisibility(View.GONE);
                }

                if (!returnPolicy.isNull("ShippingCostPaidBy")) {
                    shippingCostPaidBy = returnPolicy.getString("ShippingCostPaidBy");
                }else {
                    shippingCostPaidBy = "";
                    ShippingDetails.layout_shipped_by.setVisibility(View.GONE);


                }


                String globalShipping ;
                String conditionDisplayName ;
                String handlingTime = (itemObj.getString("HandlingTime").contains("1")||itemObj.getString("HandlingTime").contains("0"))? itemObj.getString("HandlingTime")+"day":itemObj.getString("HandlingTime")+"days";

                if (!itemObj.isNull("GlobalShipping")) {
                    globalShipping = itemObj.getString("GlobalShipping");
                }else {
                    globalShipping = "";
                }

                if (!itemObj.isNull("ConditionDisplayName")) {
                    conditionDisplayName = itemObj.getString("ConditionDisplayName");
                }else {
                    conditionDisplayName = "";
                }

                product_title_info.setText(title);
                product_price_info.setText("$"+currentPrice+" ");
                desc_text.setText(Html.fromHtml(description));
                price_entry.setText(currentPrice);
                brand_text.setText(nameValuePair.getJSONObject(0).getString("Value").replace("[\"","").replace("\"]",""));

                for (int i=0; i<nameValuePair.length();i++){

                    TextView textView = new TextView(getActivity());
                    textView.setId(i);
                    textView.setTextSize(18);
                    textView.setText("\u2022  "+nameValuePair.getJSONObject(i).getString("Value").replace("[\"","").replace("\"]",""));
                    specs.addView(textView);
                }

                /*product_ship_info.setText(shippingCost);*/
                JSONArray pictureURL = itemObj.getJSONArray("PictureURL");
                ImageLoader imageLoader = new ImageLoader(getContext());
                for (int i = 0; i < pictureURL.length(); i++) {
                    ImageView imageView = new ImageView(getActivity());
                    imageView.setId(i);
                    //imageView.setPadding(2, 2, 2, 2);
                    imageLoader.DisplayImage(pictureURL.getString(i),imageView);
                    imageView.setMinimumWidth(700);
                    imageView.setMinimumHeight(3500);
                    layout.addView(imageView);
                }




                ShippingDetails.shipping_text.setText(prod_price);
                ShippingDetails.global_text.setText(globalShipping);
                ShippingDetails.handling_text.setText(handlingTime);
                ShippingDetails.condition_text.setText(conditionDisplayName);

                ShippingDetails.ploicy_text.setText(returnsAccepted);
                ShippingDetails.within_text.setText(returnsWithin);
                ShippingDetails.refund_text.setText(refund);
                ShippingDetails.shipped_text.setText(shippingCostPaidBy);

                ShippingDetails.store_text.setText(userID);
                ShippingDetails.feedback_text.setText(feedbackScore);
                ShippingDetails.popularity_rating.setText(positiveFeedbackPercent);
                if (feedbackRatingStar.equals("Blue")) {
                    ShippingDetails.feedback_star.setImageDrawable(getActivity().getDrawable(R.drawable.ic_blue_star));
                } else if (feedbackRatingStar.equals("Green")) {
                    ShippingDetails.feedback_star.setImageDrawable(getActivity().getDrawable(R.drawable.ic_green_star));
                } else if (feedbackRatingStar.equals("GreenShooting")) {
                    ShippingDetails.feedback_star.setImageDrawable(getActivity().getDrawable(R.drawable.ic_shoot_green));
                }else if (feedbackRatingStar.equals("Purple")) {
                    ShippingDetails.feedback_star.setImageDrawable(getActivity().getDrawable(R.drawable.ic_purple_star));
                }else if (feedbackRatingStar.equals("PurpleShooting")) {
                    ShippingDetails.feedback_star.setImageDrawable(getActivity().getDrawable(R.drawable.purple_shootstars));
                }else if (feedbackRatingStar.equals("Red")) {
                    ShippingDetails.feedback_star.setImageDrawable(getActivity().getDrawable(R.drawable.ic_red_star));
                }else if (feedbackRatingStar.equals("RedShooting")) {
                    ShippingDetails.feedback_star.setImageDrawable(getActivity().getDrawable(R.drawable.red_shooting));
                }else if (feedbackRatingStar.equals("SilverShooting")) {
                    ShippingDetails.feedback_star.setImageDrawable(getActivity().getDrawable(R.drawable.ic_shoot_silver));
                }else if (feedbackRatingStar.equals("TurquoiseShooting")) {
                    ShippingDetails.feedback_star.setImageDrawable(getActivity().getDrawable(R.drawable.teal_shooting));
                }else if (feedbackRatingStar.equals("Turquoise")) {
                    ShippingDetails.feedback_star.setImageDrawable(getActivity().getDrawable(R.drawable.ic_teal_star));
                }else if (feedbackRatingStar.equals("Yellow")) {
                    ShippingDetails.feedback_star.setImageDrawable(getActivity().getDrawable(R.drawable.icyellow_star));
                }else if (feedbackRatingStar.equals("YellowShooting")) {
                    ShippingDetails.feedback_star.setImageDrawable(getActivity().getDrawable(R.drawable.yellow_shooting));
                }else{
                    ShippingDetails.feedback_star.setImageDrawable(getActivity().getDrawable(R.drawable.ic_blue_star));
                    ShippingDetails.feedback_star.setColorFilter(Color.DKGRAY);
                }


                if (!itemObj.isNull("storeInfo")){
                    JSONObject storeInfo = itemObj.getJSONObject("storeInfo");
                    /*final String storeURL = storeInfo.getString("storeURL");
                    String storeName = storeInfo.getString("storeName");
                    ShippingDetails.store_text.setText(storeName);
                    WebAPIS webAPIs= new WebAPIS();
                    webAPIs.setShipNavUrl(storeURL);*/
                    Toast.makeText(getContext(),""+storeInfo,Toast.LENGTH_LONG).show();
                }
                else  if (!itemObj.isNull("Storefront")){
                    ShippingDetails.store_text.setText(userID);
                    JSONObject storeInfo = itemObj.getJSONObject("Storefront");
                    /*final String storeURL = storeInfo.getString("storeURL");
                    String storeName = storeInfo.getString("storeName");
                    ShippingDetails.store_text.setText(storeName);
                    WebAPIS webAPIs= new WebAPIS();
                    webAPIs.setShipNavUrl(storeURL);*/
                    Toast.makeText(getContext(),""+storeInfo.getString("storeURL"),Toast.LENGTH_LONG).show();
                    //temp = storeInfo.getString("storeURL");
                }
                else {
                    ShippingDetails.store_text.setText(userID);
                }

                if (itemObj.isNull("shippingInfo")){
                    product_ship_info.setText("Free Shipping");
                }
                else {
                    JSONArray shippingcost = itemObj.getJSONArray("shippingInfo").getJSONObject(0).getJSONArray("");
                    Log.d("HW","Ship Cost == $"+(shippingcost));
                }



            } catch (Exception e) {

            }

        }
    }
}
