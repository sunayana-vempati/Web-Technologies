package com.example.hw9.utils;

public class WebAPIS {

   public static final String Local_URL = "http://hw8-ebay.us-east-2.elasticbeanstalk.com/";
   // public static final String Local_URL = "http://10.26.140.109:8081/";

    public static final String Final_URL = Local_URL;

    public static final String ZIP_CODE_LIST = Final_URL + "auto?zip=";
    public static final String FIND_RES_LIST = Final_URL + "find_results_now?keyword=";
    public static final String FIND_PRODUCT_DETAILS = Final_URL + "search_product_details?itemid=";
    public static final String FIND_SIMILAR_PRODUCTS = Final_URL + "search_similar_items?itemid=";
    public static final String FIND_GOOGLE_PICS = Final_URL + "search_google_photos?title=";

    public static final String prodUrlForFb = "https://www.facebook.com/dialog/share?app_id=184484190795&\n" +
            "channel_url=https%3A%2F%2Fstaticxx.facebook.com%2Fconnect%2Fxd_arbiter%2Fr%2Fd_vbiawPdxB.js%3Fversion%3D44%23cb%3Df2b6ab35266bc9%26domain%3Dwww.fbrell.com%26origin%3Dhttp%253A%252F%252Fwww.fbrell.com%252Ff323e9ef22763b%26relation%3Dopener&display=popup&e2e=%7B%7D&\n" +
            "fallback_redirect_uri=http%3A%2F%2Fwww.fbrell.com%2Fsaved%2F2779dc018c325d85d650a3b723239650&href=";
    public static final String prodUrlForFb1 = "&locale=en_US&next=https%3A%2F%2Fstaticxx.facebook.com%2Fconnect%2Fxd_arbiter%2Fr%2Fd_vbiawPdxB.j" +
            "s%3Fversion%3D44%23cb%3Df119c951e77464%26domain%3Dwww.fbrell.com%26origin%3Dhttp%253A%252F%252Fwww.fbrell.com%252Ff323e9ef22763b%26relatio" +
            "n%3Dopener%26frame%3Df3402567c6b7e8%26result%3D%2522xxRESULTTOKENxx%2522&hashtag=%23CSCI571Spring2019Ebay&quote=";

    public String getShipNavUrl() {
        return shipNavUrl;
    }

    public void setShipNavUrl(String shipNavUrl) {
        this.shipNavUrl = shipNavUrl;
    }

    public String shipNavUrl;

}