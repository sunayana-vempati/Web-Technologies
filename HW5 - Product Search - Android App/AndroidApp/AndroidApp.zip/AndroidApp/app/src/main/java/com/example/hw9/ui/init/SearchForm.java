package com.example.hw9.ui.init;

public class SearchForm {
    public String category;
    public String keyword;
    public int distance=10;
    public String location;
    public double lat;
    public double lon;
    public String new1;
    public String used;
    public String unspecified;
    public String local;
    public String free;

    public String getGeoHashCode() {
        return geoHashCode;
    }

    public void setGeoHashCode(String geoHashCode) {
        this.geoHashCode = geoHashCode;
    }

    public String geoHashCode;

    public boolean isOtherLocation() {
        return isOtherLocation;
    }

    public void setOtherLocation(boolean otherLocation) {
        isOtherLocation = otherLocation;
    }

    public boolean isOtherLocation;

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public int getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public String getlocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }


    public void setlocation(String location) {
        this.location = location;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLon() {
        return lon;
    }

    public void setLon(double lon) {
        this.lon = lon;
    }

    public void setNew(String new1) {
        this.new1=new1;
    }
    public void setUsed(String used) {
        this.used=used;
    }
    public void setUnspecified(String unspecified) {
        this.unspecified=unspecified;
    }
    public void setLocal(String local) {
        this.local=local;
    }public void setFree(String free) {
        this.free=free;
    }

}
