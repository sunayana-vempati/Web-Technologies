package com.example.hw9.ui.fragment.Main;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.hw9.ProductResultsAdapter;
import com.example.hw9.R;
import com.example.hw9.ui.Storage.SharedPreferenceConfig;

public class WishlistFragment extends Fragment {

    View rootview;
    public static TextView total_price,items_count,no_fav;
    SharedPreferenceConfig preferenceConfig;
    public static double price = 0.0;
    RecyclerView recyclerView;
    ProductResultsAdapter adapter;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        rootview = inflater.inflate(R.layout.fragment_wishlist, container, false);
        items_count = (TextView) rootview.findViewById(R.id.items_count);
        total_price = (TextView) rootview.findViewById(R.id.total_price);
        no_fav = (TextView) rootview.findViewById(R.id.no_fav);
        recyclerView = (RecyclerView) rootview.findViewById(R.id.fav_recyclerview);
        preferenceConfig = new SharedPreferenceConfig(inflater.getContext());
        if (preferenceConfig.loadSharedPreferencesLogList().size() == 0){
            no_fav.setVisibility(View.VISIBLE);
        }
        else {
            no_fav.setVisibility(View.GONE);
            adapter = new ProductResultsAdapter(preferenceConfig.loadSharedPreferencesLogList(),getContext());
            adapter.notifyDataSetChanged();
            recyclerView.setLayoutManager(new GridLayoutManager(getActivity(),2));
            recyclerView.setAdapter(adapter);

            for (int i=0;i<preferenceConfig.loadSharedPreferencesLogList().size();i++){
                price += Double.parseDouble(preferenceConfig.loadSharedPreferencesLogList().get(i).getProductPrice());
            }

            items_count.setText("("+String.valueOf(preferenceConfig.loadSharedPreferencesLogList().size()+" items):"));
            total_price.setText("$"+String.valueOf(price));
        }

        return rootview;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onResume() {
        super.onResume();
        adapter = new ProductResultsAdapter(preferenceConfig.loadSharedPreferencesLogList(),getContext());
        adapter.notifyDataSetChanged();
        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(),2));
        recyclerView.setAdapter(adapter);
    }
}