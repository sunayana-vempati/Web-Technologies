package com.example.hw9.ui.fragment.Main;

import android.app.ProgressDialog;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.hw9.ActivityProductDetails;
import com.example.hw9.GoogleImagesResultsAdapter;
import com.example.hw9.R;
import com.example.hw9.ui.init.ProductDetails;
import com.example.hw9.utils.WebAPIS;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class GooglePhotos extends Fragment {
    int responseCode;
    ProgressDialog dialog = null;
    View rootview;
    List<ProductDetails> productDetails = new ArrayList<ProductDetails>();
    RecyclerView recyclerview;
    GoogleImagesResultsAdapter googleImagesResultsAdapter;

    public GooglePhotos() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootview = inflater.inflate(R.layout.google_pics, container, false);
        recyclerview = (RecyclerView) rootview.findViewById(R.id.recyclerview);
        new getProductImages().execute(WebAPIS.FIND_GOOGLE_PICS+ActivityProductDetails.productTitle);
        return rootview;
    }

    public class getProductImages extends AsyncTask<String, String, String> {

        protected void onPreExecute() {
            super.onPreExecute();
            dialog = new ProgressDialog(getActivity());
            dialog.setMessage("Please wait");
            dialog.setCancelable(false);
            dialog.show();
        }

        @Override
        protected String doInBackground(String... voids) {

            StringBuffer stringBuffer = new StringBuffer();
            try {
                URL url = new URL(voids[0]);
                HttpURLConnection httpConnection = (HttpURLConnection) url.openConnection();
                httpConnection.connect();
                if (httpConnection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    InputStream stream = httpConnection.getInputStream();
                    InputStreamReader isr = new InputStreamReader(stream);
                    BufferedReader br = new BufferedReader(isr);
                    String line = "";
                    while ((line = br.readLine()) != null) {
                        stringBuffer.append(line + "\n");
                    }
                    responseCode = httpConnection.getResponseCode();
                    return stringBuffer.toString();

                } else {
                    return "Not valid";
                }
            } catch (Exception e) {
            }
            return null;
        }

        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (dialog.isShowing()) {
                dialog.dismiss();
            }

            if (responseCode == 200) {

            } else {
                Toast.makeText(getContext(), "Server down,Please Try Again After some time", Toast.LENGTH_LONG).show();
            }
            try {

                JSONObject jsonObject = new JSONObject(result);
                JSONArray items = jsonObject.getJSONArray("items");

                for (int i=0;i<items.length();i++){
                    ProductDetails getterSetter = new ProductDetails();
                    String gLink = items.getJSONObject(0).getString("link");
                    getterSetter.setItemURL(gLink);
                    productDetails.add(getterSetter);
                }
                googleImagesResultsAdapter = new GoogleImagesResultsAdapter(productDetails,getContext());
                recyclerview.setLayoutManager(new LinearLayoutManager(getActivity()));
                recyclerview.setAdapter(googleImagesResultsAdapter);


            } catch (Exception e) {

            }

        }

    }
}
