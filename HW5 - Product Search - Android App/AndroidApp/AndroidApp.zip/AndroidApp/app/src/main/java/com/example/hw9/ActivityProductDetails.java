package com.example.hw9;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.example.hw9.Adapter.ProductDetailsAdapter;
import com.example.hw9.ui.Storage.SharedPreferenceConfig;
import com.example.hw9.ui.fragment.Main.ProductInformation;
import com.example.hw9.utils.WebAPIS;


public class ActivityProductDetails  extends AppCompatActivity{
    TabLayout tabLayout;
    ViewPager viewPager;
    ImageView back,facebook;
    TextView productName;
    public static  String productTitle,productId;
    FloatingActionButton floating_btn_add,floating_btn_rem;
    SharedPreferenceConfig sharedPreferenceConfig;
    String prodClassInfo;
    String[] textArray = {"PRODUCT","SHIPPING","PHOTOS","SIMILAR"};
    int[] drawableArray = {R.drawable.ic_product_info,R.drawable.ic_shipping,R.drawable.ic_google,R.drawable.ic_menu};
    private String productPrice;

    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);

        tabLayout=(TabLayout)findViewById(R.id.tabLayout);
        viewPager=(ViewPager)findViewById(R.id.viewPager);
        back=(ImageView)findViewById(R.id.back_btn);
        productName=(TextView)findViewById(R.id.head_text);
        facebook=(ImageView)findViewById(R.id.facebook_share);
        floating_btn_add=(FloatingActionButton) findViewById(R.id.floating_btn_add);
        floating_btn_rem=(FloatingActionButton) findViewById(R.id.floating_btn_rem);

        prodClassInfo = getIntent().getStringExtra("prod");

        sharedPreferenceConfig = new SharedPreferenceConfig(ActivityProductDetails.this);

        if (sharedPreferenceConfig.isInCart(productId)){
            floating_btn_add.setVisibility(View.VISIBLE);
            floating_btn_rem.setVisibility(View.GONE);
        }
        else {
            floating_btn_add.setVisibility(View.GONE);
            floating_btn_rem.setVisibility(View.VISIBLE);
        }

        floating_btn_add.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View v) {
                sharedPreferenceConfig.saveSharedPreferencesLogList(prodClassInfo);
                floating_btn_add.setVisibility(View.GONE);
                floating_btn_rem.setVisibility(View.VISIBLE);
                Toast.makeText(ActivityProductDetails.this,productTitle+"is Added to Cart",Toast.LENGTH_LONG).show();
            }
        });

        floating_btn_rem.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View v) {
                sharedPreferenceConfig.removeFromSharedPref(prodClassInfo);
                floating_btn_rem.setVisibility(View.GONE);
                floating_btn_add.setVisibility(View.VISIBLE);
                Toast.makeText(ActivityProductDetails.this,productTitle+"is Removed from your Cart",Toast.LENGTH_LONG).show();
            }
        });

        productTitle=getIntent().getStringExtra("prod_title");
        productPrice=getIntent().getStringExtra("prod_price");

        productName.setText(productTitle);
        Log.d("HW", "productName ------ " + productTitle);
        productId=getIntent().getStringExtra("prod_id");
        Log.d("HW", "productId ------ " + productId);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        facebook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fbID = WebAPIS.prodUrlForFb+ProductInformation.fbproductlink+WebAPIS.prodUrlForFb1+"Buy "+productTitle+"for $"+productPrice+" from Ebay!";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(fbID));
                startActivity(i);
            }
        });


        for (int i=0; i<textArray.length;i++){
            TabLayout.Tab tab = tabLayout.newTab().setCustomView(R.layout.custom_tab_design);
            View view= tab.getCustomView();
            TextView txtCount= (TextView) view.findViewById(R.id.text_tab);
            ImageView image = (ImageView) view.findViewById(R.id.image_tab);

            txtCount.setText(textArray[i]);
            image.setImageDrawable(getResources().getDrawable(drawableArray[i]));

            tabLayout.addTab(tab);
        }

        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

        final ProductDetailsAdapter adapter = new ProductDetailsAdapter(this,getSupportFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(adapter);

        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }

}