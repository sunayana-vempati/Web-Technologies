package com.example.hw9.ui.Storage;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.preference.PreferenceManager;
import android.support.annotation.RequiresApi;

import com.example.hw9.ui.init.ProductDetails;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class SharedPreferenceConfig {

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private Context context;


    public SharedPreferenceConfig(Context context) {
        this.context = context;
        sharedPreferences = context.getSharedPreferences("HW09",Context.MODE_PRIVATE);
    }

    public boolean isInCart(String productId){

        if (sharedPreferences.getString(productId,"").isEmpty() || sharedPreferences.getString(productId,"").equals("")){
            return true;
        }else
        return false;
    }


    @RequiresApi(api = Build.VERSION_CODES.N)
    public void saveSharedPreferencesLogList(String details){
        editor = sharedPreferences.edit();
        ProductDetails productDetails = new Gson().fromJson(details, ProductDetails.class);
        productDetails.setWish(true);
        details = new Gson().toJson(productDetails);
        editor.putString(productDetails.getProductId(), details);
        editor.commit();
        loadSharedPreferencesLogList();
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public List<ProductDetails> loadSharedPreferencesLogList() {
        List<ProductDetails> savedCollage = new ArrayList<>();
        Map<String, ?> eventDetailMap = this.sharedPreferences.getAll();

        if (eventDetailMap == null || eventDetailMap.isEmpty()) {
            return savedCollage;
        } else {
            List<Object> savedCollages = eventDetailMap.values().stream().collect(Collectors.toList());
            for (Object collage : savedCollages) {
                savedCollage.add(new Gson().fromJson(collage.toString(), ProductDetails.class));
            }
        }

        return savedCollage;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void removeFromSharedPref(String details) {
        ProductDetails productDetails = new Gson().fromJson(details, ProductDetails.class);
        productDetails.setWish(false);
        SharedPreferences.Editor editor = this.sharedPreferences.edit();
        editor.remove(productDetails.getProductId());
        editor.apply();
        loadSharedPreferencesLogList();
    }


}
